    //Title: Assignment 5
    //Author: Kayla McDanel
    //Date: 23 June 2022
    //Description: Shopping cart app


class Product {
constructor (name,price){
    this.name = name;
    this.price = price;
    this.id = this.id = Math.random().toString(radix: 16).slice(2);
}
}