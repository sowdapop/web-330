export class Product{
    constructor(home, price){

        this.name=home;
        this.price=price;
    }
}